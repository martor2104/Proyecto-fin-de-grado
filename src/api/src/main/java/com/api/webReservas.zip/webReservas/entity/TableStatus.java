package com.api.webReservas.entity;

public enum TableStatus {

	PENDING, RESERVED
}
