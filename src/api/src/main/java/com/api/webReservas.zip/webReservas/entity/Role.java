package com.api.webReservas.entity;

public enum Role {
	USER, ADMIN
}
